# ATHENEA · Web del proyecto

Web estática del proyecto de investigación ATHENEA (*Adverse birTH Experience and materNal and child hEAlth*), Universidad de Granada.

## Estructura

- `index.html`: la página completa (HTML, CSS y JavaScript en un solo archivo).
- `img/`: fotografías de la portada y de las bandas entre secciones.

## Pendiente de contenido

- Resultados: títulos, autores, enlaces y años reales (ahora son textos de ejemplo entre corchetes).
- Equipo: retratos y resto de miembros del equipo investigador.
- Enlaces de «Política de privacidad» y «Cookies».

## Ver en local

Abre `index.html` en el navegador.
